<?php

$flag = false;
$sessionId = "";
$api_id = '527823c077f14e7980c892a8ab328725';
$secret = 'cfsk_ma_prod_d26c8be9f7564fa1a7fddee5a94836db_0ff44325';
$order_id = isset($_GET['trn']) ? $_GET['trn'] : "ijhuygj5hkjbhg864544413684";
$amount = isset($_GET['am']) ? $_GET['am'] : 1;
// $amount = 1;
$user_id = isset($_GET['userid']) ? $_GET['userid'] : "1";
$name = "Alshu India User";
$email = "user@gmail.com";
$mobile = isset($_GET['mob']) ? $_GET['mob'] : "1234567890";
$url = "https://api.cashfree.com/pg/orders";
$headers = array(
    "Content-Type: application/json",
    "x-api-version: 2023-08-01",
    "x-client-id: " . $api_id,
    "x-client-secret: " . $secret
);
$data = json_encode([
    'order_id' => $order_id,
    'order_amount' => $amount,
    "order_currency" => "INR",
    "customer_details" => [
        "customer_id" => "UHG" . $user_id,
        "customer_name" => $name,
        "customer_email" => $email,
        "customer_phone" => $mobile,
    ],
    "order_meta" => [
        "return_url" => 'https://alshuindia.com/cashfree/redirect.php',
        "payment_methods" => 'nb,upi'
    ]
]);

$curl = curl_init($url);

curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
curl_setopt($curl, CURLOPT_POSTFIELDS, $data);

$resp = curl_exec($curl);

curl_close($curl);
$result = json_decode($resp);
if ($result->order_status == "ACTIVE") {
    $flag = true;
    $sessionId = $result->payment_session_id;
}else{
    echo $resp;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cashfree Payment Gateway</title>

    <script src="https://sdk.cashfree.com/js/v3/cashfree.js"></script>
</head>

<body>
<?php
if($flag){ ?>
    <script>
        const cashfree = Cashfree({
            mode:"production" //or production
        });
        let checkoutOptions = {
            paymentSessionId: "<?php echo $sessionId; ?>",
            redirectTarget: "_self" //optional (_self or _blank)
        }
        cashfree.checkout(checkoutOptions);
    </script>
<?php } ?>
</body>

</html>