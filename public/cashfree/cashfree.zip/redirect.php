<script>
    <?php 
    $txnid = $_GET['site'];
    if(isset($txnid) && ( $txnid == "true" || $txnid == true)){ ?>
        window.location.href = "https://alshuindia.com/";
    <?php }else{ ?>
        window.location.href = "https://rajasthaniludo.com";
    <?php }
    ?>
</script>