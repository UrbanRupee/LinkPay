<?php

const $MERCHANTID="M22MA4PAMRRA2";
const $SALTKEY="b5ac135e-cce1-4be0-8f87-6a6dc72e9971";
const $SALTINDEX="1";
const $env=Env::PROD;
const $SHOULDPUBLISHEVENTS=true;

$phonePePaymentsClient = new PhonePePaymentClient(MERCHANTID, SALTKEY, SALTINDEX, Env::UAT, SHOLDPUBLISHEVENTS);

$merchantTransactionId = 'PHPSDK' . date("ymdHis") . "upiIntentPayTest";
$request = PgPayRequestBuilder::builder()
    ->mobileNumber("9090909090")
    ->callbackUrl("https://webhook.in/test")
    ->merchantId(MERCHANTID)
    ->merchantUserId("<merchantUserId>")
    ->amount(<amountInPaise>)
    ->deviceContext("Constants::IOS")
    ->merchantTransactionId($merchantTransactionId)
    ->paymentInstrument(
        InstrumentBuilder::getUpiIntentInstrumentBuilder()
            ->targetApp("com.phonepe.com")
            ->build()
    )
    ->build();

$response = $phonePePaymentsClient->pay($request);
$intentUrl = $response->getInstrumentResponse()->getIntentUrl();